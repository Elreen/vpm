# Elreen's Toolbox Installer

This is the small public Unity package. It opens the secure license page, polls the Worker, downloads the protected Toolbox archive and installs it as an embedded package at `Packages/com.elreen.tools`.

The activation token is encrypted with Windows DPAPI and stored at `Library/ElreenTools/activation.dat`. The full Toolbox reads the same file and refreshes the entitlement every 30 days.

The installer is distributed and updated through the Elreen VPM repository. During the first activation, the buyer enters the email address used for the Jinxxy purchase and confirms a one-time link. Later updates use the encrypted project activation without asking for the email address again.
