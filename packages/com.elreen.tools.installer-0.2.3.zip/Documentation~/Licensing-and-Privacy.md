# Licensing and privacy

The installer opens an Elreen activation page in the browser. The entered email address is used to find a paid Jinxxy order and send a one-time confirmation link. The raw email address is not written to the Unity project or the Worker's D1 database; D1 stores only a keyed, non-reversible hash for rate limiting.

The Worker stores the Jinxxy license identifier, activation identifier, package version, activation status and validation timestamps. Confirmation tokens are stored only as hashes and expire after 15 minutes. The downloaded Toolbox package is served through a short-lived, limited-use URL.

After activation, Unity stores a token encrypted with Windows DPAPI in `Library/ElreenTools/activation.dat`. The full Toolbox checks the entitlement again after 30 days. There is no fixed device limit and no additional project identifier.
