using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace Elreen.Tools.Installer
{
    public sealed class ElreenToolboxInstallerWindow : EditorWindow
    {
        private const string StylePath =
            "Packages/com.elreen.tools.installer/Editor/ElreenToolboxInstaller.uss";

        private Label statusLabel;
        private ProgressBar progressBar;
        private Button installButton;
        private VisualElement statusCard;
        private string sessionId;
        private string pollToken;
        private string activationUrl;
        private bool waitingForAuthentication;
        private bool requestInFlight;
        private bool forceAuthentication;
        private double nextPollAt;

        [MenuItem("Elreen's Toolbox/Installer & Updates", false, 20)]
        public static void OpenWindow()
        {
            ElreenToolboxInstallerWindow window = GetWindow<ElreenToolboxInstallerWindow>(
                "Toolbox Installer"
            );
            window.minSize = new Vector2(520f, 480f);
            window.Show();
        }

        private void OnEnable()
        {
            EditorApplication.update += Tick;
        }

        private void OnDisable()
        {
            EditorApplication.update -= Tick;
        }

        public void CreateGUI()
        {
            VisualElement root = rootVisualElement;
            root.Clear();
            root.AddToClassList("installer-root");
            StyleSheet style = AssetDatabase.LoadAssetAtPath<StyleSheet>(StylePath);
            if (style != null)
                root.styleSheets.Add(style);

            VisualElement header = new VisualElement();
            header.AddToClassList("installer-header");
            Label eyebrow = new Label("ELREEN'S TOOLBOX");
            eyebrow.AddToClassList("eyebrow");
            header.Add(eyebrow);
            Label title = new Label("Sign in once. You're ready.");
            title.AddToClassList("title");
            header.Add(title);
            Label description = new Label(
                "After your purchase is confirmed, the complete Toolbox is installed automatically in this Unity project."
            );
            description.AddToClassList("description");
            header.Add(description);
            root.Add(header);

            statusCard = new VisualElement();
            statusCard.AddToClassList("status-card");
            statusLabel = new Label();
            statusLabel.AddToClassList("status-label");
            statusCard.Add(statusLabel);
            progressBar = new ProgressBar { lowValue = 0f, highValue = 1f, value = 0f };
            progressBar.AddToClassList("progress");
            statusCard.Add(progressBar);
            root.Add(statusCard);

            installButton = new Button(BeginOrReopen) { text = "Install Toolbox" };
            installButton.AddToClassList("primary-button");
            root.Add(installButton);

            Label privacy = new Label(
                "Your Jinxxy purchase details are verified once in the browser and are never stored in the Unity project. The local activation is encrypted in the Library folder."
            );
            privacy.AddToClassList("privacy");
            root.Add(privacy);

            root.Add(BuildAdvancedSettings());
            RefreshExistingState();
        }

        private VisualElement BuildAdvancedSettings()
        {
            Foldout foldout = new Foldout { text = "Advanced", value = false };
            foldout.AddToClassList("advanced");
            TextField apiField = new TextField("License server")
            {
                value = ElreenInstallerSettings.ApiBaseUrl
            };
            foldout.Add(apiField);
            VisualElement row = new VisualElement();
            row.AddToClassList("advanced-row");
            Button save = new Button(() =>
            {
                ElreenInstallerSettings.ApiBaseUrl = apiField.value;
                apiField.value = ElreenInstallerSettings.ApiBaseUrl;
                SetStatus("License server saved.", StatusKind.Success, 0f);
            }) { text = "Save" };
            Button reset = new Button(() =>
            {
                ElreenInstallerSettings.ResetApiBaseUrl();
                apiField.value = ElreenInstallerSettings.ApiBaseUrl;
            }) { text = "Reset" };
            row.Add(save);
            row.Add(reset);
            foldout.Add(row);
            return foldout;
        }

        private void RefreshExistingState()
        {
            if (TryGetInstalledActivation(out ElreenActivationData activation))
            {
                SetStatus(
                    "Toolbox " + activation.packageVersion + " is installed in this project.",
                    StatusKind.Success,
                    1f
                );
                installButton.text = "Check for updates";
                return;
            }
            SetStatus("Ready to install.", StatusKind.Neutral, 0f);
        }

        private void BeginOrReopen()
        {
            if (waitingForAuthentication && !string.IsNullOrEmpty(activationUrl))
            {
                Application.OpenURL(activationUrl);
                return;
            }
            if (requestInFlight)
                return;

            if (!forceAuthentication && TryGetInstalledActivation(out ElreenActivationData activation))
            {
                CheckForUpdates(activation);
                return;
            }

            requestInFlight = true;
            installButton.SetEnabled(false);
            SetStatus("Preparing secure sign-in…", StatusKind.Working, 0.08f);
            ElreenInstallerApiClient.StartAuthentication(result =>
            {
                requestInFlight = false;
                if (this == null)
                    return;
                if (!result.Success || result.Value == null)
                {
                    Fail(result.Error);
                    return;
                }

                sessionId = result.Value.sessionId;
                pollToken = result.Value.pollToken;
                activationUrl = result.Value.activationUrl;
                waitingForAuthentication = true;
                nextPollAt = EditorApplication.timeSinceStartup + 1d;
                installButton.text = "Reopen sign-in page";
                installButton.SetEnabled(true);
                SetStatus(
                    "The browser is open. Enter your Jinxxy purchase email and license key.",
                    StatusKind.Working,
                    0.2f
                );
                Application.OpenURL(activationUrl);
            });
        }

        private void CheckForUpdates(ElreenActivationData activation)
        {
            requestInFlight = true;
            installButton.SetEnabled(false);
            SetStatus("Checking your license and available updates…", StatusKind.Working, 0.15f);
            ElreenInstallerApiClient.CheckForUpdate(activation, result =>
            {
                requestInFlight = false;
                if (this == null)
                    return;
                if (!result.Success || result.Value == null)
                {
                    forceAuthentication = result.StatusCode == 401 || result.StatusCode == 403;
                    Fail(result.Error);
                    if (forceAuthentication)
                        installButton.text = "Sign in again";
                    return;
                }

                AuthStatusResponse status = result.Value;
                ElreenActivationStore.Save(new ElreenActivationData
                {
                    activationToken = status.activationToken,
                    validUntil = status.validUntil,
                    packageVersion = status.packageVersion,
                    apiBaseUrl = ElreenInstallerSettings.ApiBaseUrl
                });

                if (status.status == "up_to_date")
                {
                    forceAuthentication = false;
                    SetStatus(
                        "Toolbox " + status.packageVersion + " is already up to date.",
                        StatusKind.Success,
                        1f
                    );
                    installButton.text = "Check for updates";
                    installButton.SetEnabled(true);
                    return;
                }

                if (status.status == "update_available" && !string.IsNullOrWhiteSpace(status.downloadUrl))
                {
                    DownloadAndInstall(status);
                    return;
                }

                Fail("The license server returned an invalid update status.");
            });
        }

        private void Tick()
        {
            if (!waitingForAuthentication || requestInFlight || EditorApplication.timeSinceStartup < nextPollAt)
                return;
            nextPollAt = EditorApplication.timeSinceStartup + 2d;
            requestInFlight = true;
            ElreenInstallerApiClient.CheckAuthentication(sessionId, pollToken, result =>
            {
                requestInFlight = false;
                if (this == null || !waitingForAuthentication)
                    return;
                if (!result.Success)
                {
                    if (result.StatusCode == 410)
                    {
                        waitingForAuthentication = false;
                        Fail("The sign-in request has expired. Start the installation again.");
                    }
                    return;
                }

                AuthStatusResponse status = result.Value;
                if (status == null || status.status == "pending")
                    return;
                if (status.status != "approved")
                {
                    waitingForAuthentication = false;
                    Fail(string.IsNullOrWhiteSpace(status.message) ? "The license was not approved." : status.message);
                    return;
                }

                waitingForAuthentication = false;
                DownloadAndInstall(status);
            });
        }

        private void DownloadAndInstall(AuthStatusResponse status)
        {
            requestInFlight = true;
            installButton.SetEnabled(false);
            SetStatus("Downloading the Toolbox securely…", StatusKind.Working, 0.35f);
            ElreenInstallerApiClient.Download(
                status.downloadUrl,
                progress =>
                {
                    if (progressBar != null)
                        progressBar.value = Mathf.Lerp(0.35f, 0.72f, progress);
                },
                result =>
                {
                    requestInFlight = false;
                    if (this == null)
                        return;
                    if (!result.Success)
                    {
                        Fail(result.Error);
                        return;
                    }

                    try
                    {
                        SetStatus("Adding the Toolbox to the project…", StatusKind.Working, 0.82f);
                        ElreenActivationStore.Save(new ElreenActivationData
                        {
                            activationToken = status.activationToken,
                            validUntil = status.validUntil,
                            packageVersion = status.packageVersion,
                            apiBaseUrl = ElreenInstallerSettings.ApiBaseUrl
                        });
                        ElreenEmbeddedPackageInstaller.Install(result.Value);
                        SetStatus(
                            "Done! Elreen's Toolbox " + status.packageVersion + " is installed.",
                            StatusKind.Success,
                            1f
                        );
                        forceAuthentication = false;
                        installButton.text = "Check for updates";
                        installButton.SetEnabled(true);
                    }
                    catch (Exception exception)
                    {
                        Fail("The Toolbox could not be installed: " + exception.Message);
                    }
                }
            );
        }

        private static bool TryGetInstalledActivation(out ElreenActivationData activation)
        {
            activation = null;
            string fullPackage = Path.Combine(
                Directory.GetCurrentDirectory(),
                "Packages",
                "com.elreen.tools",
                "package.json"
            );
            if (!File.Exists(fullPackage) || !ElreenActivationStore.TryLoad(out activation))
                return false;
            return !string.IsNullOrWhiteSpace(activation.packageVersion);
        }

        private void Fail(string message)
        {
            installButton.text = "Try again";
            installButton.SetEnabled(true);
            SetStatus(
                string.IsNullOrWhiteSpace(message) ? "The installation failed." : message,
                StatusKind.Error,
                0f
            );
        }

        private void SetStatus(string text, StatusKind kind, float progress)
        {
            if (statusLabel == null || statusCard == null || progressBar == null)
                return;
            statusLabel.text = text;
            progressBar.value = Mathf.Clamp01(progress);
            statusCard.EnableInClassList("status-success", kind == StatusKind.Success);
            statusCard.EnableInClassList("status-error", kind == StatusKind.Error);
            statusCard.EnableInClassList("status-working", kind == StatusKind.Working);
        }

        private enum StatusKind
        {
            Neutral,
            Working,
            Success,
            Error
        }
    }
}
