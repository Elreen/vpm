# Licensing and privacy

The installer opens an Elreen activation page in the browser. The purchase email and license key must belong to the same paid Jinxxy order. Neither raw value is written to the Unity project or the Worker's D1 database; D1 stores only a keyed, non-reversible email hash for rate limiting.

The Worker stores the Jinxxy license identifier, activation identifier, package version, activation status and validation timestamps. Each license can activate up to three projects. The downloaded Toolbox package is served through a short-lived, limited-use URL.

After activation, Unity stores a token encrypted with Windows DPAPI in `Library/ElreenTools/activation.dat`. The full Toolbox checks the entitlement again after 30 days. There is no hardware or device fingerprint.
