using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;

namespace Elreen.Tools.Installer
{
    [Serializable]
    internal sealed class ElreenActivationData
    {
        public string activationToken;
        public string validUntil;
        public string packageVersion;
        public string apiBaseUrl;
    }

    internal static class ElreenActivationStore
    {
        private const string ActivationFileName = "activation.dat";

        internal static string ActivationFilePath
        {
            get
            {
                return Path.Combine(
                    Directory.GetCurrentDirectory(),
                    "Library",
                    "ElreenTools",
                    ActivationFileName
                );
            }
        }

        internal static void Save(ElreenActivationData data)
        {
            if (data == null || string.IsNullOrWhiteSpace(data.activationToken))
                throw new ArgumentException("Die Aktivierungsdaten sind unvollständig.", nameof(data));

            string directory = Path.GetDirectoryName(ActivationFilePath);
            if (string.IsNullOrEmpty(directory))
                throw new IOException("Der Aktivierungsordner konnte nicht bestimmt werden.");
            Directory.CreateDirectory(directory);

            byte[] plain = Encoding.UTF8.GetBytes(JsonUtility.ToJson(data));
            byte[] protectedBytes = WindowsDpapi.Protect(plain);
            string temporaryPath = ActivationFilePath + ".tmp";
            File.WriteAllBytes(temporaryPath, protectedBytes);
            if (File.Exists(ActivationFilePath))
                File.Delete(ActivationFilePath);
            File.Move(temporaryPath, ActivationFilePath);
        }

        internal static bool TryLoad(out ElreenActivationData data)
        {
            data = null;
            if (!File.Exists(ActivationFilePath))
                return false;

            try
            {
                byte[] protectedBytes = File.ReadAllBytes(ActivationFilePath);
                byte[] plain = WindowsDpapi.Unprotect(protectedBytes);
                data = JsonUtility.FromJson<ElreenActivationData>(Encoding.UTF8.GetString(plain));
                return data != null && !string.IsNullOrWhiteSpace(data.activationToken);
            }
            catch
            {
                return false;
            }
        }
    }

    internal static class WindowsDpapi
    {
        [StructLayout(LayoutKind.Sequential)]
        private struct DataBlob
        {
            internal int DataLength;
            internal IntPtr DataPointer;
        }

        [DllImport("Crypt32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CryptProtectData(
            ref DataBlob dataIn,
            string description,
            IntPtr optionalEntropy,
            IntPtr reserved,
            IntPtr promptStructure,
            int flags,
            out DataBlob dataOut
        );

        [DllImport("Crypt32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CryptUnprotectData(
            ref DataBlob dataIn,
            IntPtr description,
            IntPtr optionalEntropy,
            IntPtr reserved,
            IntPtr promptStructure,
            int flags,
            out DataBlob dataOut
        );

        [DllImport("Kernel32.dll", SetLastError = true)]
        private static extern IntPtr LocalFree(IntPtr memory);

        internal static byte[] Protect(byte[] data)
        {
            return Transform(data, true);
        }

        internal static byte[] Unprotect(byte[] data)
        {
            return Transform(data, false);
        }

        private static byte[] Transform(byte[] data, bool protect)
        {
            if (Application.platform != RuntimePlatform.WindowsEditor)
                throw new PlatformNotSupportedException("Elreen's Toolbox unterstützt derzeit den Unity Editor unter Windows.");
            if (data == null || data.Length == 0)
                throw new ArgumentException("Leere Daten können nicht geschützt werden.", nameof(data));

            DataBlob input = new DataBlob();
            DataBlob output = new DataBlob();
            try
            {
                input.DataLength = data.Length;
                input.DataPointer = Marshal.AllocHGlobal(data.Length);
                Marshal.Copy(data, 0, input.DataPointer, data.Length);
                bool succeeded = protect
                    ? CryptProtectData(ref input, "Elreen Toolbox activation", IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 0, out output)
                    : CryptUnprotectData(ref input, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, 0, out output);
                if (!succeeded)
                    throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());

                byte[] result = new byte[output.DataLength];
                Marshal.Copy(output.DataPointer, result, 0, output.DataLength);
                return result;
            }
            finally
            {
                if (input.DataPointer != IntPtr.Zero)
                    Marshal.FreeHGlobal(input.DataPointer);
                if (output.DataPointer != IntPtr.Zero)
                    LocalFree(output.DataPointer);
            }
        }
    }
}
