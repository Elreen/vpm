using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace Elreen.Tools.Installer
{
    public sealed class ElreenToolboxInstallerWindow : EditorWindow
    {
        private const string StylePath =
            "Packages/com.elreen.tools.installer/Editor/ElreenToolboxInstaller.uss";

        private Label statusLabel;
        private ProgressBar progressBar;
        private Button installButton;
        private VisualElement statusCard;
        private string sessionId;
        private string pollToken;
        private string activationUrl;
        private bool waitingForAuthentication;
        private bool requestInFlight;
        private bool forceAuthentication;
        private double nextPollAt;

        [MenuItem("Tools/Elreen's Toolbox Installer", false, 0)]
        public static void OpenWindow()
        {
            ElreenToolboxInstallerWindow window = GetWindow<ElreenToolboxInstallerWindow>(
                "Toolbox Installer"
            );
            window.minSize = new Vector2(520f, 480f);
            window.Show();
        }

        private void OnEnable()
        {
            EditorApplication.update += Tick;
        }

        private void OnDisable()
        {
            EditorApplication.update -= Tick;
        }

        public void CreateGUI()
        {
            VisualElement root = rootVisualElement;
            root.Clear();
            root.AddToClassList("installer-root");
            StyleSheet style = AssetDatabase.LoadAssetAtPath<StyleSheet>(StylePath);
            if (style != null)
                root.styleSheets.Add(style);

            VisualElement header = new VisualElement();
            header.AddToClassList("installer-header");
            Label eyebrow = new Label("ELREEN'S TOOLBOX");
            eyebrow.AddToClassList("eyebrow");
            header.Add(eyebrow);
            Label title = new Label("Einmal anmelden. Fertig.");
            title.AddToClassList("title");
            header.Add(title);
            Label description = new Label(
                "Nach erfolgreicher Prüfung wird die vollständige Toolbox automatisch in diesem Unity-Projekt installiert."
            );
            description.AddToClassList("description");
            header.Add(description);
            root.Add(header);

            statusCard = new VisualElement();
            statusCard.AddToClassList("status-card");
            statusLabel = new Label();
            statusLabel.AddToClassList("status-label");
            statusCard.Add(statusLabel);
            progressBar = new ProgressBar { lowValue = 0f, highValue = 1f, value = 0f };
            progressBar.AddToClassList("progress");
            statusCard.Add(progressBar);
            root.Add(statusCard);

            installButton = new Button(BeginOrReopen) { text = "Toolbox installieren" };
            installButton.AddToClassList("primary-button");
            root.Add(installButton);

            Label privacy = new Label(
                "Dein Lizenzschlüssel wird im Browser geprüft und nicht im Unity-Projekt gespeichert. Die lokale Aktivierung liegt verschlüsselt im Library-Ordner."
            );
            privacy.AddToClassList("privacy");
            root.Add(privacy);

            root.Add(BuildAdvancedSettings());
            RefreshExistingState();
        }

        private VisualElement BuildAdvancedSettings()
        {
            Foldout foldout = new Foldout { text = "Erweitert", value = false };
            foldout.AddToClassList("advanced");
            TextField apiField = new TextField("Lizenzserver")
            {
                value = ElreenInstallerSettings.ApiBaseUrl
            };
            foldout.Add(apiField);
            VisualElement row = new VisualElement();
            row.AddToClassList("advanced-row");
            Button save = new Button(() =>
            {
                ElreenInstallerSettings.ApiBaseUrl = apiField.value;
                apiField.value = ElreenInstallerSettings.ApiBaseUrl;
                SetStatus("Lizenzserver gespeichert.", StatusKind.Success, 0f);
            }) { text = "Speichern" };
            Button reset = new Button(() =>
            {
                ElreenInstallerSettings.ResetApiBaseUrl();
                apiField.value = ElreenInstallerSettings.ApiBaseUrl;
            }) { text = "Zurücksetzen" };
            row.Add(save);
            row.Add(reset);
            foldout.Add(row);
            return foldout;
        }

        private void RefreshExistingState()
        {
            if (TryGetInstalledActivation(out ElreenActivationData activation))
            {
                SetStatus(
                    "Toolbox " + activation.packageVersion + " ist für dieses Projekt installiert.",
                    StatusKind.Success,
                    1f
                );
                installButton.text = "Nach Updates suchen";
                return;
            }
            SetStatus("Bereit zur Installation.", StatusKind.Neutral, 0f);
        }

        private void BeginOrReopen()
        {
            if (waitingForAuthentication && !string.IsNullOrEmpty(activationUrl))
            {
                Application.OpenURL(activationUrl);
                return;
            }
            if (requestInFlight)
                return;

            if (!forceAuthentication && TryGetInstalledActivation(out ElreenActivationData activation))
            {
                CheckForUpdates(activation);
                return;
            }

            requestInFlight = true;
            installButton.SetEnabled(false);
            SetStatus("Sichere Anmeldung wird vorbereitet …", StatusKind.Working, 0.08f);
            ElreenInstallerApiClient.StartAuthentication(result =>
            {
                requestInFlight = false;
                if (this == null)
                    return;
                if (!result.Success || result.Value == null)
                {
                    Fail(result.Error);
                    return;
                }

                sessionId = result.Value.sessionId;
                pollToken = result.Value.pollToken;
                activationUrl = result.Value.activationUrl;
                waitingForAuthentication = true;
                nextPollAt = EditorApplication.timeSinceStartup + 1d;
                installButton.text = "Anmeldeseite erneut öffnen";
                installButton.SetEnabled(true);
                SetStatus(
                    "Der Browser wurde geöffnet. Gib dort deinen Jinxxy-Lizenzschlüssel ein.",
                    StatusKind.Working,
                    0.2f
                );
                Application.OpenURL(activationUrl);
            });
        }

        private void CheckForUpdates(ElreenActivationData activation)
        {
            requestInFlight = true;
            installButton.SetEnabled(false);
            SetStatus("Lizenz und verfügbare Updates werden geprüft …", StatusKind.Working, 0.15f);
            ElreenInstallerApiClient.CheckForUpdate(activation, result =>
            {
                requestInFlight = false;
                if (this == null)
                    return;
                if (!result.Success || result.Value == null)
                {
                    forceAuthentication = result.StatusCode == 401 || result.StatusCode == 403;
                    Fail(result.Error);
                    if (forceAuthentication)
                        installButton.text = "Erneut anmelden";
                    return;
                }

                AuthStatusResponse status = result.Value;
                ElreenActivationStore.Save(new ElreenActivationData
                {
                    activationToken = status.activationToken,
                    validUntil = status.validUntil,
                    packageVersion = status.packageVersion,
                    apiBaseUrl = ElreenInstallerSettings.ApiBaseUrl
                });

                if (status.status == "up_to_date")
                {
                    forceAuthentication = false;
                    SetStatus(
                        "Toolbox " + status.packageVersion + " ist bereits aktuell.",
                        StatusKind.Success,
                        1f
                    );
                    installButton.text = "Nach Updates suchen";
                    installButton.SetEnabled(true);
                    return;
                }

                if (status.status == "update_available" && !string.IsNullOrWhiteSpace(status.downloadUrl))
                {
                    DownloadAndInstall(status);
                    return;
                }

                Fail("Der Lizenzserver hat keinen gültigen Update-Status gesendet.");
            });
        }

        private void Tick()
        {
            if (!waitingForAuthentication || requestInFlight || EditorApplication.timeSinceStartup < nextPollAt)
                return;
            nextPollAt = EditorApplication.timeSinceStartup + 2d;
            requestInFlight = true;
            ElreenInstallerApiClient.CheckAuthentication(sessionId, pollToken, result =>
            {
                requestInFlight = false;
                if (this == null || !waitingForAuthentication)
                    return;
                if (!result.Success)
                {
                    if (result.StatusCode == 410)
                    {
                        waitingForAuthentication = false;
                        Fail("Die Anmeldung ist abgelaufen. Starte die Installation erneut.");
                    }
                    return;
                }

                AuthStatusResponse status = result.Value;
                if (status == null || status.status == "pending")
                    return;
                if (status.status != "approved")
                {
                    waitingForAuthentication = false;
                    Fail(string.IsNullOrWhiteSpace(status.message) ? "Die Lizenz wurde nicht freigegeben." : status.message);
                    return;
                }

                waitingForAuthentication = false;
                DownloadAndInstall(status);
            });
        }

        private void DownloadAndInstall(AuthStatusResponse status)
        {
            requestInFlight = true;
            installButton.SetEnabled(false);
            SetStatus("Toolbox wird sicher heruntergeladen …", StatusKind.Working, 0.35f);
            ElreenInstallerApiClient.Download(
                status.downloadUrl,
                progress =>
                {
                    if (progressBar != null)
                        progressBar.value = Mathf.Lerp(0.35f, 0.72f, progress);
                },
                result =>
                {
                    requestInFlight = false;
                    if (this == null)
                        return;
                    if (!result.Success)
                    {
                        Fail(result.Error);
                        return;
                    }

                    try
                    {
                        SetStatus("Toolbox wird in das Projekt eingebunden …", StatusKind.Working, 0.82f);
                        ElreenActivationStore.Save(new ElreenActivationData
                        {
                            activationToken = status.activationToken,
                            validUntil = status.validUntil,
                            packageVersion = status.packageVersion,
                            apiBaseUrl = ElreenInstallerSettings.ApiBaseUrl
                        });
                        ElreenEmbeddedPackageInstaller.Install(result.Value);
                        SetStatus(
                            "Fertig! Elreen's Toolbox " + status.packageVersion + " ist installiert.",
                            StatusKind.Success,
                            1f
                        );
                        forceAuthentication = false;
                        installButton.text = "Nach Updates suchen";
                        installButton.SetEnabled(true);
                    }
                    catch (Exception exception)
                    {
                        Fail("Die Toolbox konnte nicht installiert werden: " + exception.Message);
                    }
                }
            );
        }

        private static bool TryGetInstalledActivation(out ElreenActivationData activation)
        {
            activation = null;
            string fullPackage = Path.Combine(
                Directory.GetCurrentDirectory(),
                "Packages",
                "com.elreen.tools",
                "package.json"
            );
            if (!File.Exists(fullPackage) || !ElreenActivationStore.TryLoad(out activation))
                return false;
            return !string.IsNullOrWhiteSpace(activation.packageVersion);
        }

        private void Fail(string message)
        {
            installButton.text = "Erneut versuchen";
            installButton.SetEnabled(true);
            SetStatus(
                string.IsNullOrWhiteSpace(message) ? "Die Installation ist fehlgeschlagen." : message,
                StatusKind.Error,
                0f
            );
        }

        private void SetStatus(string text, StatusKind kind, float progress)
        {
            if (statusLabel == null || statusCard == null || progressBar == null)
                return;
            statusLabel.text = text;
            progressBar.value = Mathf.Clamp01(progress);
            statusCard.EnableInClassList("status-success", kind == StatusKind.Success);
            statusCard.EnableInClassList("status-error", kind == StatusKind.Error);
            statusCard.EnableInClassList("status-working", kind == StatusKind.Working);
        }

        private enum StatusKind
        {
            Neutral,
            Working,
            Success,
            Error
        }
    }
}
