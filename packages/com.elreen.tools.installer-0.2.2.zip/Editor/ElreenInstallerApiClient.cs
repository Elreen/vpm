using System;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;

namespace Elreen.Tools.Installer
{
    [Serializable]
    internal sealed class AuthStartResponse
    {
        public string sessionId;
        public string pollToken;
        public string activationUrl;
        public string expiresAt;
        public string error;
    }

    [Serializable]
    internal sealed class AuthStatusRequest
    {
        public string sessionId;
        public string pollToken;
    }

    [Serializable]
    internal sealed class PackageUpdateRequest
    {
        public string activationToken;
        public string installedVersion;
    }

    [Serializable]
    internal sealed class AuthStatusResponse
    {
        public string status;
        public string message;
        public string packageVersion;
        public string activationToken;
        public string validUntil;
        public string downloadUrl;
        public string error;
    }

    internal readonly struct ApiResult<T>
    {
        internal readonly bool Success;
        internal readonly long StatusCode;
        internal readonly T Value;
        internal readonly string Error;

        internal ApiResult(bool success, long statusCode, T value, string error)
        {
            Success = success;
            StatusCode = statusCode;
            Value = value;
            Error = error;
        }
    }

    internal static class ElreenInstallerApiClient
    {
        internal static void StartAuthentication(Action<ApiResult<AuthStartResponse>> completed)
        {
            SendJson(ElreenInstallerSettings.ApiBaseUrl + "/v1/auth/start", "{}", completed);
        }

        internal static void CheckAuthentication(
            string sessionId,
            string pollToken,
            Action<ApiResult<AuthStatusResponse>> completed)
        {
            AuthStatusRequest body = new AuthStatusRequest
            {
                sessionId = sessionId,
                pollToken = pollToken
            };
            SendJson(
                ElreenInstallerSettings.ApiBaseUrl + "/v1/auth/status",
                JsonUtility.ToJson(body),
                completed
            );
        }

        internal static void CheckForUpdate(
            ElreenActivationData activation,
            Action<ApiResult<AuthStatusResponse>> completed)
        {
            PackageUpdateRequest body = new PackageUpdateRequest
            {
                activationToken = activation.activationToken,
                installedVersion = activation.packageVersion
            };
            SendJson(
                ElreenInstallerSettings.ApiBaseUrl + "/v1/package/update",
                JsonUtility.ToJson(body),
                completed
            );
        }

        internal static void Download(
            string url,
            Action<float> progress,
            Action<ApiResult<byte[]>> completed)
        {
            UnityWebRequest request = UnityWebRequest.Get(url);
            UnityWebRequestAsyncOperation operation = request.SendWebRequest();
            EditorApplication.CallbackFunction update = null;
            update = () =>
            {
                if (request == null || operation == null || operation.isDone)
                {
                    EditorApplication.update -= update;
                    return;
                }
                progress?.Invoke(Mathf.Clamp01(operation.progress));
            };
            EditorApplication.update += update;
            operation.completed += _ =>
            {
                EditorApplication.update -= update;
                bool success = request.result == UnityWebRequest.Result.Success;
                byte[] data = success ? request.downloadHandler.data : null;
                string error = success ? null : ReadError(request);
                long code = request.responseCode;
                request.Dispose();
                completed(new ApiResult<byte[]>(success, code, data, error));
            };
        }

        private static void SendJson<T>(string url, string json, Action<ApiResult<T>> completed)
            where T : class
        {
            byte[] bytes = Encoding.UTF8.GetBytes(json);
            UnityWebRequest request = new UnityWebRequest(url, UnityWebRequest.kHttpVerbPOST)
            {
                uploadHandler = new UploadHandlerRaw(bytes),
                downloadHandler = new DownloadHandlerBuffer()
            };
            request.SetRequestHeader("Content-Type", "application/json");
            UnityWebRequestAsyncOperation operation = request.SendWebRequest();
            operation.completed += _ =>
            {
                bool success = request.result == UnityWebRequest.Result.Success;
                T value = null;
                string error = null;
                if (success)
                {
                    try
                    {
                        value = JsonUtility.FromJson<T>(request.downloadHandler.text);
                        if (value == null)
                        {
                            success = false;
                            error = "Der Lizenzserver hat eine leere Antwort gesendet.";
                        }
                    }
                    catch (Exception exception)
                    {
                        success = false;
                        error = "Die Antwort des Lizenzservers konnte nicht gelesen werden: " + exception.Message;
                    }
                }
                else
                {
                    error = ReadError(request);
                }

                long code = request.responseCode;
                request.Dispose();
                completed(new ApiResult<T>(success, code, value, error));
            };
        }

        private static string ReadError(UnityWebRequest request)
        {
            string body = request.downloadHandler != null ? request.downloadHandler.text : string.Empty;
            if (!string.IsNullOrWhiteSpace(body) && body.Length < 500)
            {
                try
                {
                    AuthStatusResponse response = JsonUtility.FromJson<AuthStatusResponse>(body);
                    if (!string.IsNullOrWhiteSpace(response.error))
                        return response.error;
                    if (!string.IsNullOrWhiteSpace(response.message))
                        return response.message;
                }
                catch
                {
                    // Fall back to UnityWebRequest's transport error below.
                }
            }
            return string.IsNullOrWhiteSpace(request.error)
                ? "Der Lizenzserver ist nicht erreichbar."
                : request.error;
        }
    }
}
