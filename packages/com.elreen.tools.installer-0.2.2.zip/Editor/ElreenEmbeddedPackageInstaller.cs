using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using UnityEditor;

namespace Elreen.Tools.Installer
{
    internal static class ElreenEmbeddedPackageInstaller
    {
        private const string PackageFolderName = "com.elreen.tools";

        internal static void Install(byte[] zipBytes)
        {
            if (zipBytes == null || zipBytes.Length == 0)
                throw new InvalidDataException("Das heruntergeladene Paket ist leer.");

            string projectRoot = Path.GetFullPath(Directory.GetCurrentDirectory());
            string packagesRoot = Path.Combine(projectRoot, "Packages");
            string target = Path.Combine(packagesRoot, PackageFolderName);
            string staging = Path.Combine(packagesRoot, PackageFolderName + ".installing");
            string backup = Path.Combine(packagesRoot, PackageFolderName + ".backup");
            Directory.CreateDirectory(packagesRoot);
            DeleteDirectory(staging);
            DeleteDirectory(backup);
            Directory.CreateDirectory(staging);

            try
            {
                ExtractSafely(zipBytes, staging);
                if (!File.Exists(Path.Combine(staging, "package.json")))
                    throw new InvalidDataException("Im Download fehlt die package.json der Toolbox.");

                if (Directory.Exists(target))
                    Directory.Move(target, backup);
                try
                {
                    Directory.Move(staging, target);
                    DeleteDirectory(backup);
                }
                catch
                {
                    DeleteDirectory(target);
                    if (Directory.Exists(backup))
                        Directory.Move(backup, target);
                    throw;
                }
            }
            finally
            {
                DeleteDirectory(staging);
            }

            AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);
        }

        private static void ExtractSafely(byte[] zipBytes, string destination)
        {
            using (MemoryStream stream = new MemoryStream(zipBytes, false))
            using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Read))
            {
                List<ZipArchiveEntry> files = archive.Entries
                    .Where(entry => !string.IsNullOrEmpty(entry.Name))
                    .ToList();
                if (files.Count == 0)
                    throw new InvalidDataException("Das heruntergeladene Paket enthält keine Dateien.");

                string removableRoot = FindCommonPackageRoot(files);
                string destinationRoot = Path.GetFullPath(destination) + Path.DirectorySeparatorChar;
                foreach (ZipArchiveEntry entry in files)
                {
                    string relative = NormalizeEntryPath(entry.FullName, removableRoot);
                    if (string.IsNullOrEmpty(relative))
                        continue;
                    string outputPath = Path.GetFullPath(Path.Combine(destination, relative));
                    if (!outputPath.StartsWith(destinationRoot, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidDataException("Das Paket enthält einen ungültigen Dateipfad.");

                    string directory = Path.GetDirectoryName(outputPath);
                    if (!string.IsNullOrEmpty(directory))
                        Directory.CreateDirectory(directory);
                    using (Stream source = entry.Open())
                    using (FileStream output = File.Create(outputPath))
                        source.CopyTo(output);
                }
            }
        }

        private static string FindCommonPackageRoot(IReadOnlyCollection<ZipArchiveEntry> files)
        {
            string[] roots = files
                .Select(entry => entry.FullName.Replace('\\', '/').Split('/')[0])
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();
            return roots.Length == 1 && string.Equals(roots[0], "package", StringComparison.OrdinalIgnoreCase)
                ? roots[0] + "/"
                : string.Empty;
        }

        private static string NormalizeEntryPath(string path, string removableRoot)
        {
            string normalized = path.Replace('\\', '/');
            if (!string.IsNullOrEmpty(removableRoot) && normalized.StartsWith(removableRoot, StringComparison.OrdinalIgnoreCase))
                normalized = normalized.Substring(removableRoot.Length);
            return normalized.Replace('/', Path.DirectorySeparatorChar);
        }

        private static void DeleteDirectory(string path)
        {
            if (Directory.Exists(path))
                Directory.Delete(path, true);
        }
    }
}
