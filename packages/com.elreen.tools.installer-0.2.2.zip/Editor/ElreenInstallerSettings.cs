using UnityEditor;

namespace Elreen.Tools.Installer
{
    internal static class ElreenInstallerSettings
    {
        internal const string ProductionApiBaseUrl = "https://elreen-license-api.elreen-tools.workers.dev";
        private const string ApiUrlEditorPref = "Elreen.Tools.Installer.ApiBaseUrl";

        internal static string ApiBaseUrl
        {
            get
            {
                string value = EditorPrefs.GetString(ApiUrlEditorPref, ProductionApiBaseUrl).Trim();
                return string.IsNullOrEmpty(value) ? ProductionApiBaseUrl : value.TrimEnd('/');
            }
            set
            {
                string normalized = string.IsNullOrWhiteSpace(value)
                    ? ProductionApiBaseUrl
                    : value.Trim().TrimEnd('/');
                EditorPrefs.SetString(ApiUrlEditorPref, normalized);
            }
        }

        internal static void ResetApiBaseUrl()
        {
            EditorPrefs.DeleteKey(ApiUrlEditorPref);
        }
    }
}
