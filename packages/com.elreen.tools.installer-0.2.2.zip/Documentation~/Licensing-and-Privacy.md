# Licensing and privacy

The installer opens an Elreen license page in the browser and submits the entered license key to the Elreen Cloudflare Worker, which checks it with Jinxxy. The raw license key is not written to the Unity project or the Worker's D1 database.

The Worker stores the Jinxxy license identifier, activation identifier, package version, activation status and validation timestamps. The downloaded Toolbox package is served through a short-lived, limited-use URL.

After activation, Unity stores a token encrypted with Windows DPAPI in `Library/ElreenTools/activation.dat`. The full Toolbox checks the entitlement again after 30 days. There is no fixed device limit and no additional project identifier.
